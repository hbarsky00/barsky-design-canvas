# Trading Without Friction

> A crypto trading interface designed for two audiences the industry insists you have to choose between.

**Tags:** Fintech, Crypto, Product Design, Dual-Mode UX

**URL:** /project/crypto


## The Problem

*THE PROBLEM*

'Easy' crypto apps (Coinbase, Cash App) hide complexity and charge premium spreads. 'Pro' apps (Kraken, Binance) expose everything and assume you brought your own confidence. Both audiences get screwed differently. Beginners pay for hidden fees and never graduate. Pros pay for every 'are you sure?' tax built for someone else.


## What Didn't Work

First version of beginner mode was too protected. Confirmations everywhere, tooltips on every term, an onboarding tour that wouldn't quit. People felt patronized, not safe. Fix: explain on hover, confirm only above a threshold, get out of the way otherwise. Pro mode had the opposite problem — I'd cut so much that some pros couldn't find features they relied on. Density is a feature for that audience, not a bug.

- ![Failed prototype iterations and stakeholder feedback sessions](https://barskyux.com/wp-content/uploads/2025/08/Learning.jpg)

## Final Product

Two modes, one platform, shared core. Beginner mode strips the chart, uses plain English, surfaces explanations next to anything that costs money. Pro mode shows the full order book and zero hand-holding. Mode is a setting, not a separate product — beginners can see Pro exists, pros can flip to Beginner to help a friend without switching accounts. Plain language as a design constraint, not a copy pass: if we couldn't explain something in one sentence, we either explained it inline or cut it from beginner mode. Total cost — including spread — sits next to the action button. Every time. Most-fought decision, one I'd defend hardest.

- ![Competitor analysis exposing beginner exploitation](https://barskyux.com/wp-content/uploads/2025/08/competetive-2.png)
- ![User Flow Chart for Crypto App](https://barskyux.com/wp-content/uploads/2025/09/cryptotrade_site_map_flowchart_better.png)
- ![Initial concepts challenging crypto app conventions](https://barskyux.com/wp-content/uploads/2025/09/Initial-Flow-of-screens-scaled.png)
- ![Design thinking process for crypto platform](https://barskyux.com/wp-content/uploads/2025/09/designthinkingupdate.png)

## Outcome

Pros and beginners using the same platform without either feeling like it was built for the other one. That was the goal. — What I Didn't Solve: Intermediate traders fit awkwardly in either mode. A v2 would probably need a third mode or more granular customization.
