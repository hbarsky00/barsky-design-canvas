# Investor Loan Platform

> Replacing Excel as the system of record for multi-million-dollar loan deals — without anyone losing their workflow.

**Tags:** Enterprise, FinTech, Workflow Design

**URL:** /project/investor-loan-app


## The Problem

*THE PROBLEM*

A bank running loan ops in Excel. Multi-million-dollar deals, no audit trail, no validation. Three previous replacement attempts had failed because they tried to 'improve' things officers didn't want changed.


## What Didn't Work

First version replicated too much of Excel's structure because I was trying to minimize cognitive change. Worst of both worlds — looked like Excel, didn't behave like it. Rewrite went the other direction: looked nothing like Excel, behaved like what officers actually needed. Also over-invested in dashboards early. Officers don't start their day on a dashboard. They open a specific deal.

- ![User testing session showing loan officer workflow validation](/lovable-uploads/70efa220-d524-4d37-a9de-fbec00205917.png)

## Final Product

Inline validation that catches malformed entries the moment they happen. Invisible when right, obvious when wrong. No modals, no error logs. Predictive search instead of filters — loan officers think in fragments, a name, a deal code. Bloomberg-style search beats filter panels for this audience. Guided order builder with disabled forward steps: pick the lender, then terms become editable. Feels restrictive in screenshots, less restrictive in practice. Audit trail surfaced next to the record, not buried in an admin tool. This is the feature that made compliance actually advocate for adoption.

- ![Excel-based loan tracking spreadsheet with inconsistent fields and manual totals](https://barskyux.com/wp-content/uploads/2025/08/excelterror.jpg)
- ![Collage highlighting legacy manual steps and fragmentation](https://barskyux.com/wp-content/uploads/2025/08/uxpilot-design-1756062303031-scaled.png)
- ![Low-fidelity order builder wireframe for loan workflows](https://barskyux.com/wp-content/uploads/2023/12/BookBuilder-Low-Fidelity.png)
- ![Whiteboard mapping of loan lifecycle from application to audit](https://barskyux.com/wp-content/uploads/2023/12/whiteboarding.png)
- ![Investor loan platform user workflow and process improvements](/lovable-uploads/6e0291a5-2519-4b89-8402-44a9b8a27cf0.png)

## Outcome

Adoption happened — which for an Excel-replacement project is the only outcome that matters. Three previous attempts hadn't gotten that far.
