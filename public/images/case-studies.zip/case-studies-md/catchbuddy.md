# CatchBuddy

> Same-day pickup sports, designed for trust. Post a game, see open games, confirm in a few taps. Built solo with AI as a co-builder.

**Tags:** AI-Assisted Product, Trust & Safety, Mobile-First, Solo Build

**Live:** https://catchbuddy.me

**URL:** /project/catchbuddy


## Hero Metrics

- **Solo Build** — Designer + AI, end-to-end
- **Safety-First Architecture** — Minor approval, panic button, curated meeting spots
- **Real Stack Shipped** — Auth, RLS, OAuth, Stripe, Realtime

## Research

**Observing pickup-sports culture and existing apps surfaced three friction points:**



### Emerging Themes

- **LEAGUE-FOCUSED APPS DON'T SERVE CASUAL PLAY** — Existing platforms assume commitment, schedules, recurring teams. Most people want one game this weekend, not a season. → Drove: a single-action "post a catch request" as the entire product.
- **TRUST IS THE REAL UNLOCK, NOT MATCHING** — Two strangers meeting at a park requires a different safety model than dating apps or marketplaces. → Drove: phone verification, panic button, curated meeting spots, minor approval flow — built in from v1.
- **"MATCHES" READS AS DATING** — Early testers consistently misread the nav. → Drove: rewrote navigation as "Browse" and "Players" instead of "Matches."

## The Problem

*THE REAL PROBLEM*

Pickup sports are dying in cities. Existing apps are league-focused or chat-heavy. Nobody wants a Slack thread to throw a baseball after work. The real product wasn't another scheduling tool — it was a way to lower the friction and the safety risk of two strangers agreeing to meet at a park.


## Sprint Zero



**Decision:** Ship the minimum viable trust loop — post a game, see games, confirm a match — and only then layer in the safety scaffolding (phone verification, panic button, minor approval). No discovery without trust signals in place.

- ![Post Your Game — sport picker with Football, Basketball, Baseball, Volleyball, Frisbee](/images/catchbuddy-post-game.png)
- ![Choose a Park — searchable list with distance and amenities](/images/catchbuddy-choose-park.png)

## Key Insights

### 1. Safety can't be a bolt-on. It's the product.

Minors require a verified parent on file before they can post. The panic button reaches every in-game screen. Public meeting spots are curated, not crowdsourced. None of that comes from a prompt — those are product calls about who's actually going to use this and what could go wrong.

### 2. AI scaffolds the schema. It doesn't decide who's allowed to post.

AI shipped the RLS policies, the profiles_public view, the Supabase migrations, the Stripe integration, the OAuth flow. The trust model — who gets in, who's gated, what's surfaced — was every decision I made by hand.

### 3. Real reviews surface things AI misses.

AI's own security code review caught a recursive RLS policy on the profiles table that would have leaked data in production. Used the AI as a second pair of eyes, not as the only set.


**Concepts:** [object Object], [object Object], [object Object]

![Equipment and preferences — "I'll bring a football," no-contact toggle](/images/catchbuddy-equipment-prefs.png)

## My Thought Process

The product had to be honest about who was using it. Two strangers, a park, a real game on a real day. Every design decision was checked against: would I let my 16-year-old cousin sign up for this? That filter killed open-ended chat, killed crowdsourced meeting spots, and gated everything for minors behind a verified parent.


## User Testing

Tested with friends, family, and parents reviewing the minor-approval flow on real iOS and Android phones. Changes from observation: "Matches" → "Browse" and "Players" — users read "Matches" as Tinder-like. Toast stacking — auto-dismiss after 3 seconds. Bottom nav layout shift — fixed to grid-cols-5 to prevent jumps when badges appear. Calendar OAuth state — rewrote with HMAC-SHA256 signing after CSRF vulnerability was caught. Demo data leakage — separated demo matches into their own query path with a Demo badge.

- ![Find Players list with 92% and 81% match scores — proximity + time heuristic surfaced as percentages users instantly understand](/images/catchbuddy-find-players.png)
- ![Sign-up form with the 13+ age gate — first checkpoint in the minor-protection flow](/images/catchbuddy-signup-minor-gate.png)

## What Didn't Work

The Quick Start wizard was over-engineered onboarding. Users wanted to skip it. Cut. The homepage MapSection promised value the first interaction couldn't deliver. Cut. Apple Calendar, Outlook, and ICS support were built. Three calendar providers turned out to be a maintenance tax for a feature users barely cared about. Google-only now.

- ![Confirmation — "Your Game is Live!" with nearby player count, not a vanity counter](/images/catchbuddy-game-live.png)

## Outcome

A shipped pickup-sports platform with auth, RLS, Stripe payments, Google Calendar OAuth, realtime updates, a minor-approval flow, and curated meeting spots — designed and built solo with AI as a co-builder. Trust-first architecture: safety scaffolding built in from v1, not bolted on. Real stack: auth, RLS, OAuth, Stripe, Realtime, all shipped. User-driven cuts: every removed feature backed by observed friction. AI as collaborator: schema scaffolding, security review, copy drafts, edge functions.
