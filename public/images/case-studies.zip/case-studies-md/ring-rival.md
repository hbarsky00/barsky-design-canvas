# Ring-Rival

> Console boxing feel on the mobile web. Distinct AI opponents, AI-generated trash talk, career mode — built solo with AI as a co-builder.

**Tags:** AI-Assisted Product, Mobile Web, Game Design, Solo Build

**Live:** https://rival.li

**URL:** /project/ring-rival


## Hero Metrics

- **Solo Build** — Designer + AI, no team
- **22s → 6s** — Time to first punch after testing
- **~40% → <2%** — Audio failure rate after the first-tap gate

## Research

**Observing real players on real phones revealed three problems:**



### Emerging Themes

- **STATIC TUTORIALS DON'T WORK** — A 4-step calibration wizard, a daily challenges modal, and a how-to page all tested poorly. Six of six testers skipped the how-to before their first fight. → Drove: if the first fight doesn't teach the controls in 10 seconds, no screen will.
- **MOBILE AUDIO IS UNRELIABLE BY DEFAULT** — iOS Safari kills audio that isn't triggered by user gesture. ~40% of first sessions launched silent. → Drove: AudioContext resume gated behind the first tap on the title screen.
- **AI OPPONENTS NEED RHYTHM, NOT TIMERS** — Early opponents threw punches at fixed intervals. Felt like fighting a metronome. → Drove: an EmotionEngine where opponents bait, hesitate, and tilt based on how the player is doing.

## The Problem

*THE REAL PROBLEM*

Boxing games live on consoles for a reason — tight input latency, animation feel, and AI that reads like a real opponent. Doing all of that with a thumb on a phone, in a browser, no install, was the constraint that made the project worth building. The design question wasn't "can we ship a boxer," it was "can we ship one that feels right."


## Sprint Zero



**Decision:** Verify game feel on a single archetype (Glass Joe) before generating any other fighters. If a punch doesn't feel good against the easiest opponent, no amount of AI sprite generation will save the project.

- ![VS Glass Joe controls modal with input scheme](/images/ringrival-controls-modal.png)
- ![Von Kaiser — tall, broad, defensive guard](/images/ringrival-vonkaiser.png)

## Key Insights

### 1. AI generates fighters endlessly. Sequencing them is design.

Sprite generation, trash talk, announcer intros, and crowd mood all came from AI prompts. Deciding the career order — Glass Joe → Von Kaiser → Bald Bull → … → the final boss — is a difficulty curve, hand-built across hundreds of test fights.

### 2. Game feel is the part you can't prompt.

Hit-stop duration, screen shake amplitude, the 60ms haptic on connect, the curve of the health bar drain — all hand-tuned by feel. No model knows whether a punch feels like a punch.

### 3. Mobile ergonomics are decided by watching a real hand on a real phone.

Where the punch button lives, how big the block zone is, whether the music toggle belongs top-right or in a menu — every one of these was settled by handing a phone to someone and watching them play.


**Concepts:** [object Object], [object Object], [object Object]

![Knockdown — DOWN! 5 count with star burst over floored Glass Joe](/images/ringrival-knockdown.png)

## My Thought Process

The whole game is a series of small calibration calls that AI can't make: is this punch satisfying, is this opponent fun to fight, is this control discoverable. AI's job was to generate raw material — sprites, voice lines, schemas, refactors — at a speed that made hundreds of micro-iterations possible. My job was to be the taste filter on every output.


## User Testing

Tested in person and remotely on iOS and Android phones, ages 14–47, with screen and face recording. Key changes from observation: time-to-first-punch dropped from 22s to 6s by cutting menus and tutorial screens. Audio failure rate dropped from ~40% to under 2% by gating AudioContext resume behind the first tap. Webcam hand-tracking and AR mode were cut — half the testers refused the camera prompt and bounced.

- ![Glass Joe getting hit — red impact particles dialed back so fighter stays visible](/images/ringrival-impact-particles.png)
- ![Pause modal mid-fight vs. Disco Dan — Resume / Music Off / Forfeit reachable without breaking flow](/images/ringrival-pause-modal.png)

## What Didn't Work

The original calibration wizard, daily challenges modal, and how-to page were all built and all ignored. Cut. Webcam-based hand-tracking was technically impressive and the wrong mechanic for the audience. Removed entirely, along with all AR-mode references in SEO and the menu. Multiplayer and leaderboards exist as components but are gated. Shipping them requires moderation I didn't want to own in v1.

- ![Disco Dan — completely different silhouette and personality from Glass Joe](/images/ringrival-discodan.png)

## Outcome

A shipped boxing game with distinct AI opponents, generated trash talk, hand-tuned game feel, and a deployment cadence of 3–6 builds a day. Real users, real cuts, real opponents. Distinct opponents — each with their own silhouette, voice, and rhythm. AI as content engine — sprites, trash talk, intros, crowd reactions. Designer as taste filter — every output checked against "does this feel good." Iteration cadence: ship → watch a session → fix the loudest thing → reship.
