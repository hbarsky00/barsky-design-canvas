# HerbaLink

> Verified herbalists, designed around trust. A booking platform shipped solo with AI as a co-builder.

**Tags:** AI-Assisted Product, Healthcare, Trust & Safety, Solo Build

**Live:** http://herbalink.live

**URL:** /project/herbalink


## Hero Metrics

- **Solo Build** — Designer + AI, end-to-end
- **Credentials as a Gate** — Verified against an external registry, not a badge
- **Smaller Catalog by Design** — Honest beats exhaustive

## Research

**Talking to users turning to herbalism revealed three problems:**



### Emerging Themes

- **DISCOVERY IS A MISINFORMATION FIELD** — Instagram practitioners with no credentials, Google results that mix certified herbalists with weekend-workshop graduates, supplement interactions nobody warns about. → Drove: a credentialed directory gated by external verification.
- **TRUST IS THE PRODUCT, NOT SEARCH** — One user: "I found an herbalist on Instagram who promised to cure my anxiety with a $200 tincture. Turns out she had zero credentials and the herbs made me violently sick." → Drove: making the safe path the easy path, not warning labels on the unsafe one.
- **FILTER-HEAVY UX FEELS LIKE WEBMD** — A user testing the early filter panel: "This feels like trying to diagnose myself on WebMD." → Drove: replaced filters with a guided triage intake.

## The Problem

*THE REAL PROBLEM*

People turn to herbalism for anxiety, fatigue, and conditions conventional medicine isn't addressing for them — and the discovery experience is a misinformation field. The design job wasn't to build a bigger directory. It was to make the safe path the easy path, in a category where being wrong has real medical consequences.


## Sprint Zero



**Decision:** Build the catalog around external verification first. No practitioner is visible until their credentials are checked against the American Herbalists Guild or equivalent. Smaller catalog, honest one — discovery comes second.

- ![Initial concepts and sketches focused on the credential gate, not the directory layout](https://barskyux.com/wp-content/uploads/2025/08/findanherbalistsketch.png)
- ![Flow exploration — credential gate sits before any browsing](https://barskyux.com/wp-content/uploads/2025/08/ChatGPT-Image-Aug-19-2025-11_19_58-PM.png)

## Key Insights

### 1. "Verified" as a gate is a different product than "verified" as a badge.

Most directories let anyone list themselves and slap a badge on profiles that pass a basic check. Inverting that — no practitioner is visible until verified — produces a smaller, more honest catalog. That distinction is the product.

### 2. Users say "more options," they mean "more confidence in the option I pick."

Adding 200 practitioners to the early catalog made the experience worse, not better. The win came from removing anyone whose credentials couldn't be verified — even when the catalog visibly shrank.

### 3. AI can build the directory in a weekend. Deciding who doesn't appear in it is the actual product.

AI handled scaffolding, Supabase schemas, RLS policies, edge functions, the symptom intake structure, and copy variants. The credential model — which certifications matter for which conditions, when to refuse a listing — was every call I made by hand.


**Concepts:** [object Object], [object Object], [object Object]

![HerbaLink user flow from onboarding to booking](https://i0.wp.com/barskyux.com/wp-content/uploads/2025/07/UserFlow.png?fit=1232%2C928&ssl=1)

## My Thought Process

In a category dominated by misinformation, the design job is to make the safe path the easy path. Not to add warning labels to the unsafe path. Every decision was checked against: would this protect a user from the same $200-tincture mistake? That filter killed open-ended search, killed crowdsourced practitioner listings, and inverted "verified" from a badge into a gate.


## User Testing

Tested with users actively searching for herbalists, plus a smaller group reviewing the safety and intake flows on real iOS and Android phones. Changes from observation: "This feels like WebMD" → filter panel replaced with guided triage intake. "I want to know what changed since last time" → symptom tracker cut from health diary to a single follow-up question. "Are these people actually qualified?" → credential gate made visible on the profile, not buried in an FAQ.

- ![Symptom tracker — final form, after the comprehensive version was cut](https://barskyux.com/wp-content/uploads/2025/08/Symptom-Trackerupdate-scaled.png)

## What Didn't Work

The original architecture was a giant filterable database of every herbalist I could find. Wrong product — users didn't want options, they wanted confidence. Reset. The comprehensive symptom diary tried to be a health journal. Users opened it twice and abandoned it. Cut back to one question that they actually use. The "Verified" badge approach was abandoned entirely in favor of the gate model.

- ![HerbaLink early Book an Herbalist concept — before the credential gate was inverted](https://barskyux.com/wp-content/uploads/2025/07/herbalistdemo-2.png)

## Outcome

A shipped booking platform where every listed practitioner has externally verified credentials, where intake replaces search, and where the safer path is also the easier one. Credential gate verified against an external registry, not a badge. Guided intake replaces filter panels and reduces WebMD-style anxiety. Honest catalog — smaller by design, with no unverified tier. AI as scaffolder: schema, RLS, intake structure, copy variants; judgment stayed human.
