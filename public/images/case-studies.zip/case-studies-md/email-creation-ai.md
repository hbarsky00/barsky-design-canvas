# ManuscriptRx

> A self-initiated concept for AI-assisted pharma HCP email production — designed around the approval gates, not around the AI.

**Tags:** Enterprise, Gen AI, Pharma, Workflow Design

**URL:** /project/email-creation-ai


## The Problem

*THE PROBLEM*

A regulated pharma email touches a medical writer, content ops, brand, MLR, and CRM. Each handoff is a different tool. Two weeks is fast. The obvious 'dump the manuscript in and ship it' story is wrong because regulated email requires human review at specific gates. Thesis: The AI's job is the work between humans, not the work humans do.


## Final Product

Six-step workflow, each step has a clear owner and a clear gate. Brief Creation locked as 'Outside pilot scope' — the brief exists upstream. Saying that out loud is more useful than pretending I'd designed it. PromoMats integration warning stays visible on screen. Unresolved decisions in the open, not hidden. QC sits inline with editing, not after. AI auto-pass + Content Ops + Med Writer signoff happen while the writer is still in the content. 'Send Preview to Brand Team' doesn't appear until the AI checklist passes. Wrong action not available > warning when you take it. Designed every screen in Figma, then used Claude to write a Markdown spec per screen — purpose, states, role permissions, AI behavior, edge cases. Spec went to dev.

- ![Step 2 — Assemble From Approved Content: AI-owned manuscript on the left, market-specific compliance content auto-pulled on the right](/images/emailai-screen2-assemble.png)
- ![Step 3 — Iterate / Edit + Quality Checks: AI chat with live email preview on top, three role-owned QC cards on the bottom](/images/emailai-screen3-iterate-qc.png)
- ![Step 5 — Test Email: HTML generation and metadata checklist on the left, mobile and desktop email previews on the right](/images/emailai-screen6-pre-mlr.png)

## Outcome

A point of view: AI handles everything between human decisions, never replaces them. The screens are evidence of that thesis. — What I Haven't Solved: The MLR review experience. I designed the artifacts MLR receives but not the review tool itself — how MLR reviewers annotate, reject, and approve claims with legal accountability. That's the hardest part of pharma email and I'm not going to pretend I solved it in a concept project.
