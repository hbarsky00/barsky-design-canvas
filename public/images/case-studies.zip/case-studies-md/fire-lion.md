# Fire Lion

> A shipped game, built solo with AI. A one-tap arcade runner where you spell words mid-flight to cast spells.

**Tags:** AI-Assisted Product, Game Design, Mobile Web, Solo Build

**Live:** https://firelion.me

**URL:** /project/fire-lion


## Hero Metrics

- **Solo Build** — One designer, AI as co-builder
- **Daily Playtests** — Self + friends, real phones
- **6 Systems Cut** — After watching real users

## Research

**Watching real players on real phones surfaced three patterns:**



### Emerging Themes

- **FEATURE BLOAT KILLS FUN** — Daily missions, streaks, daily-word challenges, social proof counters — all added, all ignored. → Drove: a ruthless deletion list and a single-mode core loop.
- **GAME FEEL CAN'T BE PROMPTED** — AI shipped collision math and particle systems in minutes. The lion still felt like a balloon for 30 iterations. → Drove: hand-tuned gravity, tap impulse, and scroll curves over hundreds of test runs.
- **PLAYERS WANT SURPRISE, NOT SHOPPING** — Forge upgrade screens and pre-run skill trees tested badly. People wanted to play. → Drove: removed every pre-run friction point. Tap FLY is the only path in.

## The Problem

*THE REAL PROBLEM*

Most "I built X with AI" portfolios are a calculator, a dashboard, a productized audit. Safe. Forgettable. The harder question — can a designer ship a real product solo with AI? — needed a harder answer. A game. Game feel can't be faked with a prompt.


## Sprint Zero



**Decision:** Build the smallest possible playable loop first — one tap, one lion, no words, no worlds, no audio — and only add a mechanic after the core gesture feels good.

- ![Lightning Strike spell casting from spelling MN](/images/firelion-spelling-lightning.png)
- ![Spelling CRAP over a lava forge anvil, 5× combo](/images/firelion-spelling-combo.png)

## Key Insights

### 1. Building features is easy with AI. Killing features is the actual design work.

AI happily shipped daily missions, streaks, a forge upgrade screen, mod gating, and three premium fighter modes. Users used none of them. The deletion list ended up longer than the feature list — and the game got better with every removal.

### 2. AI handles the work between human decisions. It doesn't replace them.

AI scaffolded Supabase schemas, Tailwind tokens, particle systems, and refactors across 30+ files at a time. Every gravity tweak, tap impulse, and difficulty threshold was still mine — hand-tuned by feel over hundreds of test runs.

### 3. Three modes serve three moods. Isolation is the design rule that makes it work.

Fire Lion (tense, escalating), Lion Wars (strategic), Cub Mode (low-stakes recovery). Cub Mode lives in its own component with its own audio and state — enforced in the AI memory file so even at 2am, six prompts deep, the rule holds.


**Concepts:** [object Object], [object Object], [object Object]

![Lion Wars naval combat, wave 1 of 7, lava cavern backdrop](/images/firelion-lionwars-combat.png)

## My Thought Process

The whole project was held together by one question, asked over every feature: does this make the player want one more run? If yes, keep. If no — even if AI built it in minutes, even if it tested fine in isolation — cut. That filter is what separates a tech demo from a game, and it's the part AI can't do.


## User Testing

Tested with friends and family on real iOS and Android phones, plus daily self-playtests (minimum 10 runs per day). Qualitative changes that shipped from feedback: "Why is the first board always the same boss?" → randomized world order per run. "I can never revive." → full rewrite of revive UI and availability logic. "The lion flies too slowly at the start." → killed the slow-start mechanic. "It's stupid I can't move left and right in Cub Mode." → added horizontal movement.

- ![Cub Mode sunset scene — kept isolated from the main game so refactors never break it](/images/firelion-cubmode-sunset.png)
- ![Cub Mode ocean scene — same isolation rule: separate component, separate audio, separate state](/images/firelion-cubmode-ocean.png)

## What Didn't Work

The first version had daily missions, a streak system, a daily Wordle-style challenge, a legacy cumulative score, a social proof counter, a forge pre-run upgrade screen, and mod gating behind a "Lava Rank" tier. All shipped fast thanks to AI. All ignored by players. All removed. Lion Wars originally triggered between worlds in the runner. Players hated being yanked out of flow. The trigger was removed; the code stays in the codebase for a Phase 2 integration directly into the main runner.


## Outcome

A shipped game with three modes, real retention loops, a deletion list longer than its feature list, and a clear thesis: AI can scaffold a game in a week, but deciding which 80% to throw away is the year of design work that makes it playable. Three modes — Fire Lion, Lion Wars, Cub Mode. Solo design end-to-end — UI, mechanics, economy, audio, art direction. Ruthless deletion discipline — every cut backed by observed player behavior. Reusable AI memory file keeps the next session in perfect context.
