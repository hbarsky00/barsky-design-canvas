# BarskyJoint

> One ordering system that works on a kiosk and a phone, without making either feel like a compromise.

**Tags:** Restaurant Tech, Food Service, Kiosk Design

**Live:** https://barskyjoint.com

**URL:** /project/barskyjoint


## The Problem

*THE PROBLEM*

A burger with 14 customizations, all shown at once, freezes people. On a kiosk a line forms behind them. On web they close the tab.


## What Didn't Work

First version showed all customization upfront. I thought I was being thorough. Three test sessions in, people were stalling on the toppings screen for a burger they'd already decided on — pulled it back to defaults-plus-expand. Also tried to make the kiosk feel 'modern' with animation. On a kiosk, animation is latency. Cut almost all of it.

- ![Failed early restaurant ordering interface design](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/Barskyjoint800.jpg)

## Final Product

Every item ships with a sensible default. Two taps and you're done — customize inline if you want, no modal, no new screen. Same components on kiosk and web, with tap targets sized for thumbs vs. cursors: one design system, calibrated per device. The order summary stays visible at all times instead of living on a separate cart page.

- ![Menu confusion analysis from restaurant ordering interface](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/mainpagedesktop.jpg)
- ![Customer journey mapping for restaurant ordering flow](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/journeymap0.jpg)
- ![Decision point analysis for ordering platform design](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/uxpilot-design-1757973264652.png)

## Outcome

Faster orders and fewer mid-order abandonments in early testing. No post-launch numbers I'd stand behind.
