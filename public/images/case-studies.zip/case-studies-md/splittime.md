# SplitTime

> A co-parenting app designed around the fact that every interaction is potential evidence.

**Tags:** Family Tech, Legal UX, Mobile

**Live:** https://splittime.pro

**URL:** /project/splittime


## The Problem

*THE PROBLEM*

Most co-parenting apps are calendars with chat bolted on. They treat the job as logistics. The hard part isn't logistics — it's that 'are you picking her up at 5 or 5:30?' reads as accusatory when you're already angry, and by message four nobody's talking about pickup anymore.


## What Didn't Work

First cut had a free-form messaging feature because it felt cruel not to. Wrong — open messaging is where the conflict lives. Removing it felt counterintuitive until I watched someone visibly relax when I told them there wasn't one. Also tried neutral-language nudges ('did you mean to say...'). Felt patronizing in testing. Templates are the version of that idea that works.

- ![Early Splittime interface with feature overload](https://barskyux.com/wp-content/uploads/2024/01/Screenshot-2025-05-03-at-10.10.22%E2%80%AFPM-e1748480830908.png)

## Final Product

Structured requests, not open chat. The primary pattern is a clear ask → approve / decline / counter-propose → stamped timestamp. No room for tone, clean record if it ever needs to be one. Templates for the 80% of co-parenting communication that's the same conversation every week — pickup confirmations, expense reimbursements, schedule adjustments — strip the emotional charge out of routine messages. Change history as a first-class feature: every approval, modification, expense — timestamped and immutable. Knowing the record exists changes how people behave. Shared schedule and child profile, both parents can see everything.

- ![Initial Concepts & Sketches](https://barskyux.com/wp-content/uploads/2025/08/Dashboard0.jpg)
- ![User Flow Explorations](https://barskyux.com/wp-content/uploads/2025/08/wireframing-1.webp)
- ![Messaging System](https://barskyux.com/wp-content/uploads/2025/08/6.Messages.png)
- ![Splittime user satisfaction metrics and communication improvements](https://barskyux.com/wp-content/uploads/2016/08/ideation_phase_design.png)
- ![Expenses Tracking](https://barskyux.com/wp-content/uploads/2025/08/4.Expenses.png)
- ![Documents Storage](https://barskyux.com/wp-content/uploads/2025/08/5.Documents.png)
- ![Calendar View](https://barskyux.com/wp-content/uploads/2025/08/3.calendar.png)
- ![Child Profile](https://barskyux.com/wp-content/uploads/2025/08/7.ChildProfile.png)

## Outcome

Parents testing it described it as 'the first one that didn't make me feel like I was being managed.' That's the response I was designing for.
