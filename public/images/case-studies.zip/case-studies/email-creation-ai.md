# ManuscriptRx: Designing an AI-Assisted Email Creation Workflow for Pharma

> A self-initiated concept project — a 6-step AI-assisted workflow that replaces the broken handoffs in pharma HCP email production with one platform built around real roles and approval gates.

**Tags:** Concept Project, Enterprise, Gen AI, Pharma, Workflow Design


## Tech Stack

- **AI Tools:** Claude, ChatGPT
- **Dev Stack:** React, TypeScript
- **Design Tools:** Figma


## Hero

![Step 1 — Content Planning: 6-step workflow navigator with Brief Creation locked and Initiate Email Creation active](/images/emailai-screen1-content-planning.png)



## Hero Metrics

- **6** — Workflow steps
- **4** — Roles designed for
- **1** — Honest open problem


## My Thought Process

**Step 1 — Content Planning**
The workflow opens with a 6-step progress navigator so users always see where they are, what's next, and who owns what. The center panel is a plain-language prompt above filterable brief cards.
*Design decision:* Brief Creation is locked on purpose — "Outside pilot scope" — because the brief already exists upstream. I also surfaced the PromoMats metadata warning rather than hide it, so a manager can see I understood the integration problems, not just the happy path.

**Step 2 — Assemble From Approved Content**
The AI owns this step entirely. Left panel: the full manuscript. Right panel: what got pulled automatically — product name verified against brand guidelines, market-specific safety links, unsubscribe block, privacy notice. The human reviews and either approves or requests changes.
*Design decision:* The two sticky notes about claims libraries and PromoMats image sourcing stay visible. In a real spec, unresolved decisions need to be in the open.

**Step 3 — Iterate / Edit + Quality Checks**
The most complex screen, intentionally. Top half: AI Assistant chat on the left, live email preview on the right with modifiable sections in teal and locked compliance sections in grey. Role tabs gate what each person can touch. Bottom half: three QC cards — AI runs an automatic pass/fail (no new claims, language in bounds, accessibility, latest ISI, working unsubscribe), Content Ops reviews it, Med Writer signs off.
*Design decision:* QC sits inline with editing so issues get caught while the writer is still in the content, not after it's "done."

**Step 5 — Test Email**
HTML is generated via Knak. The left checklist validates character limits, mobile truncation, hero image size, link resolution, responsive formatting, alt text, tracking tags, and table structure. The right panel renders the email side-by-side in mobile and desktop.
*Design decision:* The "Send Preview to Brand Team" button doesn't appear until the AI checklist passes. A deliberate guardrail, not a technical limitation.

**Step 6 — Pre-MLR RV Package**
See "What I Haven't Solved" above — flagged here as the open problem rather than buried in the flow.

**How I built the spec**
I designed every screen in Figma, then used Claude to write a structured Markdown file per screen — purpose, component states, role permissions, AI behavior, edge cases. Those MD files went to the dev team as the build spec. Writing in plain language exposed assumptions wireframes hide.

![Step 1 — Content Planning: 6-step navigator with Brief Creation locked and Initiate Email Creation active](/images/emailai-screen1-content-planning.png)

![Step 2 — Assemble From Approved Content: AI-owned manuscript on the left, market-specific compliance content auto-pulled on the right](/images/emailai-screen2-assemble.png)

![Step 3 — Iterate / Edit + Quality Checks: AI chat with live email preview on top, three role-owned QC cards on the bottom](/images/emailai-screen3-iterate-qc.png)

![Step 5 — Test Email: HTML generation and metadata checklist on the left, mobile and desktop email previews on the right](/images/emailai-screen6-pre-mlr.png)



## What Didn't Work

I designed the AI outputs (RV PDF, annotations panel, based-on declaration) but not the review experience itself — how MLR reviewers annotate, reject, and approve claims with legal accountability. That's the hardest part of pharma email and would need direct research with MLR and legal.



## Outcome

The temptation is to add AI everywhere and call it smart. The real question is simpler: how do we make sure the right person is looking at the right thing at the right time — and the AI handles everything in between? That framing drove every screen.

- **Roles** — Med Writer · Content Ops · Brand · MLR
- **Gates** — Designed around real approvals
- **AI** — Owns the work between humans
- **Spec** — Markdown handoff per screen
