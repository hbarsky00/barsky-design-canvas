# Redesigning Loans: 85% Fewer Errors, 40% Faster

> How I led a banking platform redesign that replaced Excel and scaled operations with speed, accuracy, and trust.

**Tags:** FinTech, Analytics, WebApp


## Tech Stack

- **AI Tools:** ChatGPT, Synthetic Data Gen
- **Dev Stack:** React, TypeScript, PostgreSQL
- **Design Tools:** Figma, Excel Analysis


## Hero Video

[Video](investor-loan-demo.mp4)

![poster](https://barskyux.com/wp-content/uploads/2025/08/analysisdashboard-1.png)


## Research

### Digging into the pain points

Why Excel was breaking loan operations

- **ACCURACY & AUDIT** — Copy/paste errors and unclear totals created compliance risk. _Drove: Inline validation, calculated totals, and immutable change history._
- **FINDABILITY** — Officers struggled to locate deals/borrowers across files. _Drove: Predictive, category-aware search with contextual filters._
- **GUIDED ORDERS** — Flat forms caused premature inputs and rework. _Drove: Stepwise flows with disabled actions until lender selection, plus real-time feedback._

![Excel-based loan tracking spreadsheet with inconsistent fields and manual totals](https://barskyux.com/wp-content/uploads/2025/08/excelterror.jpg)



## The Real Problem

**The critical challenge**

> Compliance risks hidden in spreadsheets: Loan teams were managing multi-million-dollar deals in fragile spreadsheets, with no audit trail or validation. Errors slipped through, reconciliation was manual, and regulators had no trustworthy data to review.


## Sprint Zero


**Decision:** The data showed most errors stemmed from missing validation and flat forms. I focused on building an intelligent workflow system—automation, checks, and audit trails—instead of adding unnecessary financial modeling.

![Low-fidelity order builder wireframe for loan workflows](https://barskyux.com/wp-content/uploads/2023/12/BookBuilder-Low-Fidelity.png)

![Whiteboard mapping of loan lifecycle from application to audit](https://barskyux.com/wp-content/uploads/2023/12/whiteboarding.png)



## Key Insights

### 1. Trust through validation

Real-time checks prevent costly errors.

### 2. Predictive findability

Bloomberg-style search beats filter hell.

### 3. Guided orders

Stepwise flows reduce mistakes vs. flat forms.



## Ideation

### Exploring solutions: Designing the building blocks of trust

- 
- 
- 
- 

**Iteration 1:** 



**Iteration 2:** 



**Iteration 3:** 



**Iteration 4:** 





## My Thought Process

I treated this as a process problem, not a screen problem. By shadowing loan officers, I saw scattered data, manual mistakes, and compliance blind spots. The answer wasn't prettier forms—it was automation, validation, and transparency.

![Investor loan platform user workflow and process improvements](/lovable-uploads/6e0291a5-2519-4b89-8402-44a9b8a27cf0.png)



## User Testing

Testing validated that automation and audit trails significantly improved both speed and compliance.

- **95%** — Task Completion
- **85%** — Error Reduction
- **60s** — Avg. Search Time

![User testing session showing loan officer workflow validation](/lovable-uploads/70efa220-d524-4d37-a9de-fbec00205917.png)
*Testing sessions confirmed my automated validation approach significantly reduced processing errors.*



## What Didn't Work

At first, we recreated too much of Excel's flat structure. Users were overwhelmed, and errors persisted. The fix: guided workflows, card-based views, and live syncing that matched real processes instead of old habits.

![Collage highlighting legacy manual steps and fragmentation](https://barskyux.com/wp-content/uploads/2025/08/uxpilot-design-1756062303031-scaled.png)



## Final Product

We delivered a platform that replaced Excel chaos with guided workflows, real-time checks, and transparent audit trails. Officers gained confidence, regulators gained visibility, and the bank scaled with accuracy.

![Investor loan platform dashboard final interface](/lovable-uploads/70efa220-d524-4d37-a9de-fbec00205917.png)
*Complete loan management platform with automated workflows and real-time validation*

![My Deals list view with quick filters, status chips, and bulk actions](https://barskyux.com/wp-content/uploads/2023/12/My-Deals-list-view.png)

![Loan deals table with summary sidebar, inline validation, and audit trail](https://barskyux.com/wp-content/uploads/2023/12/Loan-Deals-1.png)

![Orderbook screen emphasizing guided steps and real-time totals](https://barskyux.com/wp-content/uploads/2023/12/Just-Orderbook.png)



## Outcome

The platform transformed loan operations with measurable improvements. Officers gained confidence, regulators gained visibility, and the bank scaled with accuracy.

- **85%** — Fewer Errors
- **40%** — Faster Processing
- **200+** — Orders in 2 Months
