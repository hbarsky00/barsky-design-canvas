# Smarter Health: Transforming Patient Anxiety Into Confident Self-Care

> How empathy-driven design reduced medication anxiety and helped patients trust their care routines

**Tags:** UX Design, Healthcare App, Mobile App Design, Accessibility


## Tech Stack

- **AI Tools:** ChatGPT, Figma AI
- **Dev Stack:** React Native, TypeScript
- **Design Tools:** Figma, Material Design 3.0


## Hero Video

[Video](/assets/case-studies/smarter-health/hero-video.mp4)

![poster](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/smarterhealth/frontpage.png)


## Hero Metrics

- **45%** — Less anxiety during daily routines
- **60%** — More patients trusting their care plan
- **3×** — Increase in confident health behaviors


## Research

### Managing daily medication and doctor visits can be overwhelming—especially for diabetic patients juggling multiple prescriptions and health devices.

The client's early app looked promising, but users found it confusing. Logging doses, syncing devices, and scheduling appointments required too many steps.

- **ANXIETY FROM COMPLEXITY** — Patients felt paralyzed by too many steps—existing apps like Teladoc and MySugr increased stress instead of reducing it _Drove: One-tap logging that built confidence through simplicity_
- **TRUST BREAKDOWN** — Clinical interfaces made patients feel judged, not supported—'too clinical' meant 'doesn't understand me' _Drove: Empathy-driven design that made patients feel understood and capable_
- **COMMITMENT FEAR** — Users abandoned onboarding because lengthy sign-ups signaled overwhelming future effort _Drove: Quick wins early to prove the app respects their time and builds trust_

![Early app screens showing login and calendar overview](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/smarterhealth/user-research.png)
*Early screens revealed complexity issues in medication tracking*



## The Real Problem

**The Psychological Barrier**

> Diabetic patients felt overwhelmed and anxious about managing daily medications and appointments. The real challenge wasn't building features—it was designing an experience that would make patients trust themselves to stay consistent with their care routine every single day.


## Sprint Zero


**Decision:** Defined Core Modules: Medication Tracker, Appointments & Calendar, Vitals Tracking, Patient Surveys

![Early hand-drawn sketch concepts](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/smarterhealth/sketches.png)
*Early sketches exploring medication tracking flows*

![User process flow diagram](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/smarterhealth/userprocessflow.jpg)
*User process flow showing core module interactions*



## Key Insights

### 1. Empathy over complexity

Patients needed friendliness and clarity more than feature-rich dashboards

### 2. Simplified onboarding

Reducing sign-up steps prevented 60% of drop-offs

### 3. Dual-view architecture

Admin and patient views working together improved data reliability



## Ideation

### Testing calendar, medication tracking, vitals, and surveys to reduce patient stress

- 
- 
- 
- 

![Wireframes showing admin and patient dashboard](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/smarterhealth/wireframing.png)
*Dual-view wireframes for seamless admin-patient data flow*

**Iteration 1:** 



**Iteration 2:** 





## My Thought Process

After five months of design and testing, we launched an MVP that finally felt natural for real patients. They could manage medication, appointments, and surveys in one space—and doctors received cleaner, more reliable data. The app emphasized empathy, clarity, and tone over complexity.


## User Testing

Testing revealed significant improvements in medication adherence and appointment booking

- **45%** — Faster medication entry
- **60%** — Increase in appointment adherence
- **3×** — Higher patient engagement



## What Didn't Work

Our first prototype mirrored Teladoc and MySugr—but patients said it felt 'too clinical.' We discovered that empathy, clarity, and tone were more important than complexity. Onboarding also took too long—users dropped off halfway. Simplifying sign-up became our top priority.

![Dashboard view showing lesson learnings implementation](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/smarterhealth/Dashboard%20View.png)
*Final dashboard design incorporating user feedback and lessons learned*



## Final Product

After five months of design and testing, we launched an MVP that finally felt natural for real patients. They could manage medication, appointments, and surveys in one space—and doctors received cleaner, more reliable data.

![Medication Tracking View](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/smarterhealth/medical-app-ui0.jpg)
*Simplified medication tracking interface*

![Appointment Scheduler](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/smarterhealth/other-screens.png)
*Seamless appointment booking flow*

![Digital Signature Flow](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/smarterhealth/demoui-signature.png)
*Digital consent and signature workflow*



## Outcome

Transformed patient anxiety into confident self-care behaviors. Patients moved from feeling overwhelmed to trusting their ability to manage their health. The empathy-driven approach built belief in both the app and themselves, leading to sustained behavior change.

- **45%** — Less anxiety during daily medication routines
- **60%** — More patients confident in their care plan
- **3×** — Increase in trust-driven engagement
- **68%** — Reduction in clinician data entry anxiety
