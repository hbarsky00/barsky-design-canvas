# SplitTime – Simplifying Co-Parenting with Better Planning

> Built a co-parenting app to reduce scheduling conflicts. Early tests showed a 40% decrease in communication breakdowns.

**Tags:** Blue Sky, Design Thinking, iOS→Android, Legal UX, WebApp

**Live:** https://splittime.pro


## Tech Stack

- **AI Tools:** ChatGPT, Midjourney
- **Dev Stack:** React, Firebase
- **Design Tools:** Figma, Principle


## Hero Video

[Video]()

![poster](https://i0.wp.com/barskyux.com/wp-content/uploads/2024/01/Frame-4.jpg?fit=1920%2C1080&ssl=1)


## Research

### SplitTime is a co-parenting app designed to simplify shared custody, expenses, and communication. Parents were relying on texts and spreadsheets, leading to miscommunication and stress. The vision is to create a neutral and trustworthy tool that reduces conflict and fosters trust between co-parents.

Tools create conflict.

- **ESSENTIALS TO KNOW** — Families need today's pickups, locations, and changes at a glance. _Drove: Shared calendar + unified timeline for events, notes, and expenses._
- **CONFIRMATIONS & APPROVALS** — Changes were often disputed or missed. _Drove: Request/approve flows with stamped history and notifications._
- **TONE-SAFE COMMUNICATION** — Escalations came from ad-hoc texts. _Drove: In-app templates and reminders that keep language neutral._



## The Real Problem

**Problem to Solve**

> Co-parents often lack a single source of truth for schedules, expenses, and decisions, leading to miscommunication, missed pickups, and ongoing conflict.


## Sprint Zero


**Decision:** I decided to focus on a neutral communication platform after seeing that most conflicts came from unclear tone and expectations. I chose structured templates, approval workflows, and transparent history to build accountability through clarity, instead of adding features that might make things harder.

![Initial Concepts & Sketches](https://barskyux.com/wp-content/uploads/2025/08/Dashboard0.jpg)
*Early brainstorming on co-parenting communication tools and conflict reduction strategies*

![User Flow Explorations](https://barskyux.com/wp-content/uploads/2025/08/wireframing-1.webp)
*Blue-sky exploration of scheduling workflows and neutral communication patterns*



## Key Insights

### 1. Single source of truth

One shared schedule and ledger eliminates disputes.

### 2. Consent & clarity

Approvals and change logs build trust between co-parents.

### 3. Calm communication

Neutral templates reduce conflict and decision fatigue.



## Ideation

### I tested calendar, approvals, expenses, and messaging to reduce conflict and missed handoffs.

- 
- 
- 
- 

**Iteration 1:** 



**Iteration 2:** 



**Iteration 3:** 



**Iteration 4:** 





## My Thought Process

I designed around conflict reduction first, using neutral language and clear boundaries. Many co-parenting apps miss the mark by focusing on features instead of how people feel. I built SplitTime to reduce conflict first, using neutral language, clear boundaries, and shared accountability. The result: 40% less co-parenting conflict through a platform that helps families communicate better—not just stay organized.

![Splittime user satisfaction metrics and communication improvements](https://barskyux.com/wp-content/uploads/2016/08/ideation_phase_design.png)
*Ideation phase explorations mapping Splittime’s core user flows and interaction patterns.*



## User Testing

Testing with divorced co-parents revealed the importance of neutral communication tools and clear approval workflows to prevent misunderstandings.

- **89%** — Usability Score
- **40%** — Conflict Reduction
- **2min** — Avg. Request Time

![User testing session showing co-parenting workflow validation](https://i0.wp.com/barskyux.com/wp-content/uploads/2024/01/Frame-4.jpg?fit=1920%2C1080&ssl=1)
*Testing sessions validated my neutral communication approach and approval workflow design.*



## What Didn't Work

At first, I added too many features to the scheduling interface, which overwhelmed users. I learned to focus on the basics and add advanced features slowly, based on what users needed.

![Early Splittime interface with feature overload](https://barskyux.com/wp-content/uploads/2024/01/Screenshot-2025-05-03-at-10.10.22%E2%80%AFPM-e1748480830908.png)
*Early design attempts included too many features, overwhelming stressed co-parents*



## Final Product

A co-parenting platform that prioritizes children's wellbeing through clear communication, shared scheduling, and conflict reduction tools that help separated families coordinate effectively.

![Splittime Dashboard](https://barskyux.com/wp-content/uploads/2025/08/1.Dashboard.png)
*Main dashboard showing overview of all co-parenting activities and quick actions*

![Dashboard Add Function](https://barskyux.com/wp-content/uploads/2025/08/2.Dashboard-Add.png)
*Add new events, expenses, or messages directly from the dashboard*

![Calendar View](https://barskyux.com/wp-content/uploads/2025/08/3.calendar.png)
*Shared calendar ensuring both parents stay coordinated on schedules*

![Expenses Tracking](https://barskyux.com/wp-content/uploads/2025/08/4.Expenses.png)
*Track and split child-related expenses with transparent documentation*

![Documents Storage](https://barskyux.com/wp-content/uploads/2025/08/5.Documents.png)
*Centralized document storage for important child-related paperwork*

![Messaging System](https://barskyux.com/wp-content/uploads/2025/08/6.Messages.png)
*Neutral messaging interface designed to reduce conflict and misunderstandings*

![Child Profile](https://barskyux.com/wp-content/uploads/2025/08/7.ChildProfile.png)
*Detailed child profile with important information accessible to both parents*



## Outcome

SplitTime changed the way separated families communicate and work together. It helped build healthier relationships and led to better outcomes for children.

- **40%** — Conflict Reduction
- **90%** — User Satisfaction
- **24hr** — Response Time
