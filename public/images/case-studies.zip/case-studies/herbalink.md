# HerbaLink: How I Tripled Herbalist Bookings by Solving the Trust Problem

> When your health is on the line, "trust me, bro" isn't good enough

**Tags:** Healthcare, GenAI, Trust & Safety, Booking Platform

**Live:** http://herbalink.live


## Tech Stack

- **AI Tools:** ChatGPT, AI Matching
- **Dev Stack:** React Native, Node.js
- **Design Tools:** Figma, Protopie


## Hero Video

[Video](https://barskyux.com/wp-content/uploads/2025/07/HerbaLink-Book-A-Herbalist-1.mp4)

![poster](https://barskyux.com/wp-content/uploads/2025/08/Bookanherbalistpromomobile.png)


## Research

### Gathering insights from users and practitioners

Critical patterns emerged.

- **THE TRUST CRISIS** — "I found this herbalist on Instagram who promised to cure my anxiety with a $200 tincture. Turns out she had zero credentials and the herbs made me violently sick." – Jessica, marketing manager _Drove: Problem: no credential verification, real safety risks._
- **INFORMATION OVERLOAD** — "Every herbalist website has different information. I just want to know: Is this safe for me? Will it interact with my medications? How much should I take?" – David, retiree _Drove: Problem: conflicting information, no standardized guidance._
- **EMERGING THEMES** — Essentials to Know → Safety info (contraindications, interactions, dosage) must be immediate. Personalization Matters → Matching by conditions, modalities, and availability. Trust & Transparency → Verified credentials and visible sources build confidence. _Drove: Solution framework for trust-first herbalist discovery platform._

![AHG directory — grid of herbal schools (scroll demo)](https://barskyux.com/wp-content/uploads/2025/08/AHG-directory-2025-release-animation-1.gif)

![Zocdoc signup screen interface](/zocdoc-signup.png)



## The Real Problem

**Problem**

> People seeking herbal care couldn't confidently find qualified practitioners or reliable guidance, leading to dangerous misinformation, safety risks, and abandoned treatment plans.


## Sprint Zero


**Decision:** Decision Point: Trust was the core problem. Solution: verified practitioners with transparent credentials, not a self-serve database of unvetted options.

![Initial Concepts & Sketches](https://barskyux.com/wp-content/uploads/2025/08/findanherbalistsketch.png)
*Early ideation sketches exploring herbal practitioner discovery and matching concepts*

![User Flow Explorations](https://barskyux.com/wp-content/uploads/2025/08/ChatGPT-Image-Aug-19-2025-11_19_58-PM.png)
*Blue-sky user journey mapping from symptom input to practitioner booking*



## Key Insights

### 1. Trust signals first

credentials and safety info drive bookings

### 2. Personalization wins

condition-specific matching is more effective than search

### 3. Continuity matters

booking + notes + follow-ups keep users engaged



## Ideation

### Multiple iterations on trust and discovery

- 
- 
- 
- 

**Iteration 1:** 



**Iteration 2:** 



**Iteration 3:** 



**Iteration 4:** 





## My Thought Process

I prioritized trust-building over flashy features. When health is at stake, credibility trumps convenience. The breakthrough was reframing herbalist selection as choosing a doctor, not shopping for supplements. Credentials, safety info, and guided matching came first, always.

![HerbaLink user flow from onboarding to booking](https://i0.wp.com/barskyux.com/wp-content/uploads/2025/07/UserFlow.png?fit=1232%2C928&ssl=1)
*User flow from onboarding to booking and tracking.*



## User Testing

Results:
• 92% task completion
• 4.8/5 trust score
• 30s average booking time

- **92%** — task completion
- **4.8/5** — trust score
- **30s** — average booking time

![User testing session showing booking flow validation](https://barskyux.com/wp-content/uploads/2025/08/Symptom-Trackerupdate-scaled.png)
*Testing sessions showed users could easily complete bookings with high confidence in practitioner credentials.*



## What Didn't Work

My first approach was building a giant herbalist database with every possible filter. Users hated it.

"This feels like trying to diagnose myself on WebMD. I just want someone qualified to help me." – Maria

Fix: Guided discovery with expert-matched options instead of overwhelming filters.

![HerbaLink early 'Book an Herbalist' concept](https://barskyux.com/wp-content/uploads/2025/07/herbalistdemo-2.png)
*Early concept of the 'Book an Herbalist' feature. At this stage, the flow felt underdeveloped and lacked the clarity users needed — it was clear this part of the app needed a much more thoughtful design approach.*



## Final Product

A platform where people can confidently:
• Book verified herbalists with transparent credentials
• Access safety information to avoid dangerous interactions
• Track symptoms + progress over time
• Book faster: 3× higher conversion rate

![HerbaLink final product desktop interface](https://barskyux.com/wp-content/uploads/2025/08/macbookpro.png)
*Complete HerbaLink desktop experience showing the comprehensive interface design*

![HerbaLink final product mobile interface](https://barskyux.com/wp-content/uploads/2025/08/herbalink-book-an-herbalist-scaled.png)
*HerbaLink mobile experience featuring the book an herbalist functionality*



## Outcome

Maria's feedback: "I finally found an herbalist who actually helped my fatigue. The platform made me feel safe choosing someone, and the booking was so easy."

Impact:
• 3× booking increase
• 85% match accuracy
• 24hr average response time

- **3×** — booking increase
- **85%** — match accuracy
- **24hr** — average response time
