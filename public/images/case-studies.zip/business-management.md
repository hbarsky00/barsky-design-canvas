# Blue Sky: Using Design Thinking to Reduce Enterprise Operation Errors by 68%

> When small businesses are drowning in tools, sometimes you need to throw them a lifeline

**Tags:** Enterprise, Small Business, Automation, Design Thinking

**Live:** https://in-situ-quickbooks-flow.lovable.app/


## Tech Stack

- **AI Tools:** ChatGPT, Midjourney, Cursor AI
- **Dev Stack:** React, Next.js, Supabase
- **Design Tools:** Figma, Framer


## Hero Video

[Video](https://barskyux.com/wp-content/uploads/2025/07/businessmanagement.mp4)

![poster](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/warehouse/heroimage.png?v=1)


## Research

### REPETITIVE MANUAL WORK
"I spend more time entering the same client info into different systems than actually serving clients." – Mike, freelance photographer
Solved with smart templates + automation.

Gathering insights from 47 small business owners

- **CONSOLIDATION** — Scheduling, invoicing, and tasks lived in separate systems. _Drove: Unified dashboard with linked records._
- **AUTOMATION** — Recurring work (invoices, reminders) was manual. _Drove: Recurrence, templates, and smart reminders._
- **VISIBILITY & PRIORITY** — Hard to see what needs attention now. _Drove: 'Today' view with aging statuses and alerts._

![Animated workflow of automated inventory tracking system](https://barskyux.com/wp-content/uploads/2025/07/AutomatedInventoryTrackingSystem-Claude-8July2025-ezgif.com-video-to-gif-converter.gif)
*PRIORITY BLINDNESS
"I missed a $12K payment because the overdue notice got buried under 47 other notifications." – Lisa, web developer
Solved with Today dashboard + priority scoring.*



## The Real Problem

**Problem to Solve**

> Small businesses often juggle disconnected tools for scheduling, invoicing, and tasks, wasting hours weekly and losing revenue.


## Sprint Zero


**Decision:** I decided to build a unified operations platform after seeing that most problems came from switching between tools and re-entering data. I focused on bringing core functions together, automating repetitive work, and making daily priorities clear. This approach created efficiency by integrating features, not by adding more complexity.

![Initial Concepts & Sketches](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/warehouse/userflowscreen.png)
*Initial concept sitemap mapping core modules and navigation.*

![User Flow Explorations](https://barskyux.com/wp-content/uploads/2025/08/uxpilot-design-1755796640970-scaled.png)
*User flow exploration detailing end-to-end operations from intake to invoicing.*



## Key Insights

### 1. One platform eliminates chaos

Consolidating core ops cuts tool chaos.

### 2. Automation saves hours

Recurring invoices and reminders save hours weekly.

### 3. Priority-at-a-glance prevents oversights

A single dashboard surfaces what needs attention now.



## Ideation

### Multiple iterations on the "run your day" loop

- 
- 
- 
- 



## My Thought Process

I designed around how small businesses actually operate—not how we think they should. Watching Sarah's workflow made it clear: reduce cognitive load, not add features. Result: unified platform with smart defaults and connected workflows.


## User Testing

Testing with enterprise teams revealed that consolidating multiple tools into one unified platform dramatically reduced training time and operational errors.

- **90%** — satisfaction
- **68%** — fewer errors
- **5 min** — daily setup time

![Business management warehouse operations and inventory tracking system](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/warehouse/heroimage.png?v=1)
*Testing sessions confirmed my unified approach significantly improved daily operations efficiency.*



## What Didn't Work

Too many customization options = decision paralysis. Smart defaults + minimal customization = win.

![Early business management interface with feature overload](https://barskyux.com/wp-content/uploads/2025/08/uxpilot-design-1755798369735-scaled.png)
*Early designs included too many customization options, overwhelming busy business owners*



## Final Product

Unified platform with: Smart priority dashboard, Automated invoicing, Connected scheduling, Error reduction by 68%

![Business management system final interface](https://barskyux.com/wp-content/uploads/2025/07/993shots_so.png)
*Complete business management platform with unified operations and automated workflows*



## Outcome

Sarah's email: "I just realized I haven't thought about my 'admin day' in weeks. Everything just happens automatically now."

- **68%** — Fewer Errors
- **35%** — Faster Processing
- **90%** — User Satisfaction
