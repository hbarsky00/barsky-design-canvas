# BarskyJoint – 28% Higher Average Ticket Size

> Dual-format ordering platform for web and kiosk customers with clarity, guidance, and seamless checkout

**Tags:** Restaurant Tech, Food Service, Kiosk Design, Product Design

**Live:** https://barskyjoint.com


## Hero Video

[Video](/lovable-uploads/barskyjoint-hero.mp4)

![poster](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/Barsky%20Joint%20Promo.png)


## Hero Metrics

- **+28%** — Average Ticket Size
- **-35%** — Order Time
- **-60%** — Ordering Errors
- **85%** — Customer Preference


## Research

### Restaurant interviews + customer observations revealed:

Menu Confusion

- **MENU CONFUSION** — Complex menus overwhelmed customers and slowed ordering. _Drove: Clear categorization, visual hierarchy, simplified descriptions._
- **CUSTOMIZATION COMPLEXITY** — Too many options created decision paralysis and abandoned orders. _Drove: Guided customization with smart defaults + progressive disclosure._
- **DUAL EXPERIENCE GAPS** — Web and kiosk flows were inconsistent, frustrating staff + customers. _Drove: Unified design system serving both formats seamlessly._

![Menu confusion analysis from restaurant ordering interface](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/mainpagedesktop.jpg)
*Menu confusion analysis from restaurant ordering interface*



## The Real Problem

**Problem**

> Customers abandoned orders because of confusing menus and overwhelming customization flows. Restaurants lost revenue to incomplete orders and reduced ticket size.


## Sprint Zero


**Decision:** Decision Point: Build a dual-format system that leverages each platform's strengths while maintaining consistency.

![Customer journey mapping for restaurant ordering flow](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/journeymap0.jpg)
*Foundation sketches exploring menu organization and ordering flow*

![Decision point analysis for ordering platform design](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/uxpilot-design-1757973264652.png)
*Decision point analysis for dual-format ordering system*



## Key Insights

### 1. Visual hierarchy increased confidence

customers navigated faster and ordered more.

### 2. Guided customization reduced abandonment

smart defaults balanced choice with speed.

### 3. Unified design served both formats

customers recognized patterns and staff needed less training.



## Ideation

### Multiple Iterations on Core Flows

- 
- 
- 

**Iteration 1:** 





## My Thought Process

The key was designing for speed + confidence. Progressive disclosure let customers see essentials first, then dive into details if they wanted. And platform parity meant whether ordering on kiosk or web, the experience felt familiar.


## User Testing

Results:
• ↓35% order completion time
• ↓60% customization errors
• 85% customer preference over competitor systems

- **↓35%** — order completion time
- **↓60%** — customization errors
- **85%** — customer preference

![Final BarskyJoint restaurant ordering platform interface](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/Barskyjoint800.jpg)
*Final prototype testing interface showing improved ordering flow*



## What Didn't Work

At first, showing every customization upfront created choice paralysis and higher abandonment. Moving to defaults + "expand if needed" dramatically improved completion and satisfaction.

![Failed early restaurant ordering interface design](https://ctqttomppgkjbjkckise.supabase.co/storage/v1/object/public/published-images/barskyjoint/Barskyjoint800.jpg)
*Early designs that overwhelmed customers with choices*



## Outcome

The dual-format design improved both revenue and customer experience:

• +28% average ticket size
• ↓35% order completion time
• ↓60% customization errors
• 85% of customers said they preferred it to other systems

- **+28%** — average ticket size
- **↓35%** — order completion time
- **↓60%** — customization errors
- **85%** — customer preference
